const useNativeHelper = () => {
  return {};
};

export {useNativeHelper};
