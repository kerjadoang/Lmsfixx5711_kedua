import {NativeModule} from 'react-native';
interface INativeHelperModule extends NativeModule {
  forceQuitApp: VoidCallBack;
}
