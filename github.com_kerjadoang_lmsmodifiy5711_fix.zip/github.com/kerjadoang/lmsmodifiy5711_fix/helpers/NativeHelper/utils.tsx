import {INativeHelperModule} from './nativeHelperType.d';

import {NativeModules} from 'react-native';
export const NativeHelperModule: INativeHelperModule =
  NativeModules.NativeHelperModule;
